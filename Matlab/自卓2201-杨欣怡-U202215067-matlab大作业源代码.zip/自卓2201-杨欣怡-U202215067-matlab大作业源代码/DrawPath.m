function DrawPath(hFigure, srcRect, desRect)
    % DrawPath - 绘制从一个矩形到另一个矩形的路径
    %
    % Syntax: DrawPath(hFigure, srcRect, desRect)
    %
    % 该函数用于在图形界面上绘制从一个矩形（源）到另一个矩形（目标）的路径。
    % hFigure: 图形界面的句柄
    % srcRect: 源矩形对象，包含位置和尺寸信息
    % desRect: 目标矩形对象，包含位置和尺寸信息

    % 确定路径的垂直方向
    if desRect.y > srcRect.y
        upFlag = 1; % 目标在源的下方
    elseif desRect.y < srcRect.y
        upFlag = -1; % 目标在源的上方
    else
        upFlag = 0; % 目标与源在同一水平线上
    end

    % 确定路径的水平方向
    if desRect.x > srcRect.x
        rightFlag = 1; % 目标在源的右侧
    elseif desRect.x < srcRect.x
        rightFlag = -1; % 目标在源的左侧
    else
        rightFlag = 0; % 目标与源在同一垂直线上
    end

    % 计算路径中的关键点坐标
    point1x = srcRect.x + srcRect.w / 2;
    point1y = srcRect.y + srcRect.h / 2 + upFlag * srcRect.h / 2;

    point2x = point1x;
    point2y = desRect.y + desRect.h / 2 - upFlag * (desRect.h / 2 + 3);

    point3x = desRect.x + desRect.w / 2;

    % 绘制垂直部分的路径
    if upFlag == 1
        uicontrol(hFigure, 'style', 'text', 'Position', [point1x - 1, point1y, 3, max(1, point2y - point1y)], 'backgroundColor', '[1,0,0]');
    elseif upFlag == -1
        uicontrol(hFigure, 'style', 'text', 'Position', [point1x - 1, point2y, 3, max(1, point1y - point2y)], 'backgroundColor', '[1,0,0]');
    end

    % 绘制水平部分的路径
    if rightFlag == 1
        uicontrol(hFigure, 'style', 'text', 'Position', [point2x, point2y - 1, max(1, point3x - point2x), 3], 'backgroundColor', '[1,0,0]');
    elseif rightFlag == -1
        uicontrol(hFigure, 'style', 'text', 'Position', [point3x, point2y - 1, max(1, point2x - point3x), 3], 'backgroundColor', '[1,0,0]');
    end

    % 暂停0.1秒，以便用户看到路径的绘制过程
    pause(0.1);

    % 清除路径，准备下一次绘制
    if upFlag == 1
        uicontrol(hFigure, 'style', 'text', 'Position', [point1x - 1, point1y, 3, max(1, point2y - point1y)], 'backgroundColor', '[0.9,0.9,0.9]');
    elseif upFlag == -1
        uicontrol(hFigure, 'style', 'text', 'Position', [point1x - 1, point2y, 3, max(1, point1y - point2y)], 'backgroundColor', '[0.9,0.9,0.9]');
    end

    if rightFlag == 1
        uicontrol(hFigure, 'style', 'text', 'Position', [point2x, point2y - 1, max(1, point3x - point2x), 3], 'backgroundColor', '[0.9,0.9,0.9]');
    elseif rightFlag == -1
        uicontrol(hFigure, 'style', 'text', 'Position', [point3x, point2y - 1, max(1, point2x - point3x), 3], 'backgroundColor', '[0.9,0.9,0.9]');
    end
end