clc;
clear;
close all;

% 显示器的宽度和高度，用于确定仿真窗口的大小
monitorW = 1920;
monitorH = 1080;

% 初始化客户数量
clientNum = 1;
% 预分配客户数组，假设最多有300个客户
clients(1,300) = Client();

% 创建仿真窗口
hFigure = figure('Color', [1, 1, 1], ... % 设置窗口背景为白色
                  'Position', [0.2 * monitorW, 0.2 * monitorH, 0.6 * monitorW, 0.6 * monitorH], ... % 设置窗口位置和大小
                  'Name', 'M/M/N 排队系统仿真', ... % 窗口名称
                  'NumberTitle', 'off', ... % 不显示编号
                  'MenuBar', 'none', ... % 无菜单栏
                  'Resize', 'off'); % 禁止调整窗口大小

% 首先绘制一个空的界面，稍后会更新设置
Draw(hFigure, monitorW, monitorH, [], []);

% 获取用户自定义的系统属性
[serverNum, seatNum, serverTime, totalTime, clientFrequency] = GetSettings();

% 根据用户设置更新服务台和座位的配置
[servers, seats] = UpdateSettings(hFigure, monitorW, monitorH, serverNum, seatNum, serverTime);

% 绘制包含服务台和座位的仿真界面
Draw(hFigure, monitorW, monitorH, servers, seats);

% 添加开始仿真的按钮
uicontrol(hFigure, 'style', 'pushButton', ... % 创建一个按钮
          'Position', [monitorW * 0.4/5 * 4 + 50, 15, 50, 20], ... % 设置按钮位置和大小
          'String', 'start', ... % 按钮上的文字
          'backgroundColor', '[0.8,0.8,0.8]', ... % 设置按钮背景颜色
          'fontSize', 8, ... % 设置字体大小
          'call', 'Start(servers, seats, clients, clientFrequency, serverTime, totalTime, hFigure, monitorW)'); % 按钮回调函数