function Draw(hFigure, monitorW, monitorH, servers, seats)
    %Draw - Description
    %
    % Syntax: Draw(hFigure, monitorW, monitorH, servers, seats)
    %
    % Long description��
    %
    % ���Ƴ�ʼ�ķ������
    figureW = monitorW * 0.4;
    figureH = monitorH * 0.4;
    serverNum = length(servers);
    seatNum = length(seats);

    uicontrol(hFigure, 'style', 'text', 'Position', [10, 10, figureW - 20, figureH - 20], 'String', 'M/M/N ����ϵͳ', 'backgroundColor', '[0.9,0.9,0.9]', 'fontWeight', 'bold', 'fontSize', 20);
    uicontrol(hFigure, 'style', 'text', 'Position', [figureW / 5, 5, figureW / 5, 20], 'String', '���', 'backgroundColor', '[1,1,1]', 'fontSize', 8);
    uicontrol(hFigure, 'style', 'text', 'Position', [figureW / 5 * 3, 5, figureW / 5, 20], 'String', '����', 'backgroundColor', '[1,1,1]', 'fontSize', 8);
    % �������еķ���̨
    for serverIndex = 1:serverNum
        thisServer = servers(serverIndex);
        uicontrol(hFigure, 'style', 'text', 'Position', [thisServer.x,thisServer.y,thisServer.w,thisServer.h], 'String', thisServer.name, 'backgroundColor', '[1,1,1]', 'fontSize', 10);
    end
    % �������е���λ
    for seatIndex = 1:seatNum
        thisSeat = seats(seatIndex);
        uicontrol(hFigure, 'style', 'text', 'Position', [thisSeat.x,thisSeat.y,thisSeat.w,thisSeat.h], 'String', thisSeat.name, 'backgroundColor', '[1,1,1]', 'fontSize', 10);
    end
end