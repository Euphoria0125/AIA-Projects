function Stop()
    % Stop - 停止仿真
    %
    % Syntax: Stop()
    %
    % 该函数用于停止当前正在运行的仿真。
    % 它通过设置全局变量 stopNow 为 1 来通知仿真循环停止执行。

    % 使用全局变量 stopNow 来控制仿真的停止
    global stopNow;
    
    % 设置 stopNow 为 1，表示需要停止仿真
    stopNow = 1;
end