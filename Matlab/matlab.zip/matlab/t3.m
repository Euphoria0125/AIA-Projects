% 初始条件
x0 = 2;        % x(0) = 2
v0 = 0;        % x'(0) = 0
initial_conditions = [x0, v0];

% 时间范围
t_span = [0, 10];  % 选择一个适当的时间范围

% 定义微分方程


% 求解微分方程
[t, sol] = ode45(@nonlinear_ode, t_span, initial_conditions);

% 绘制结果
figure;
subplot(2, 1, 1);
plot(t, sol(:, 1), 'b-', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel('x(t)');
title('Solution x(t) vs. Time');
grid on;

subplot(2, 1, 2);
plot(t, sol(:, 2), 'r-', 'LineWidth', 1.5);
xlabel('Time (s)');
ylabel("x'(t)");
title("Solution x'(t) vs. Time");
grid on;

function dydt = nonlinear_ode(t, y)
    % y(1) = x, y(2) = x'
    dydt = zeros(2,1);
    dydt(1) = y(2);  % x' = v
    dydt(2) = ((3*y(1) - 2*y(1)^2) * y(2) - 4*y(1)) / 4;  % x''
end

