t = out.tout;           % 提取时间数据
y = out.simout;         % 提取输出信号数据
%x = out.simout1;
% 绘制图形
figure;
hold on;
grid on;
plot(t, y);
%plot(t, x);
xlabel('Time (s)');
ylabel('Output');
title('System Output Response');
hold off;
