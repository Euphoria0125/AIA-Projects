% 洛伦兹系统参数
sigma = 10;
b = 8 / 3;
r = 28;

% 洛伦兹方程的定义
lorenz = @(t, xyz) [
    sigma * (xyz(2) - xyz(1));          % x' = sigma * (y - x)
    -xyz(1) * xyz(3) + r * xyz(1) - xyz(2); % y' = -xz + rx - y
    xyz(1) * xyz(2) - b * xyz(3)        % z' = xy - bz
];

% 初始条件
initial_conditions = [10; 1; 3];

% 时间范围
t_span = [0 50];

% 求解洛伦兹系统
[t, solution] = ode45(lorenz, t_span, initial_conditions);

% 提取解
x = solution(:, 1);
y = solution(:, 2);
z = solution(:, 3);

% 绘制图像
figure;

% x vs t 图
subplot(2, 2, 1);
plot(t, x, 'b');
xlabel('Time (t)');
ylabel('x(t)');
title('x vs. t');
grid on;

% x vs y 图
subplot(2, 2, 2);
plot(x, y, 'g');
xlabel('x');
ylabel('y');
title('x vs. y');
grid on;

% x vs z 图
subplot(2, 2, 3);
plot(x, z, 'r');
xlabel('x');
ylabel('z');
title('x vs. z');
grid on;

% y vs z 图
subplot(2, 2, 4);
plot(y, z, 'm');
xlabel('y');
ylabel('z');
title('y vs. z');
grid on;

% 设置整体布局
sgtitle('Lorenz System Simulation');
